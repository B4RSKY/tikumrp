local Config = require 'shared.config'
local Vs = Config.VipSystem

-- ===== Sync statebag on join/resource =====
CreateThread(function()
    TriggerServerEvent('tk:vip:sv:refresh')
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    TriggerServerEvent('tk:vip:sv:refresh')
end)

-- ===== Client Exports (tanpa os.time) =====
local function getVipMap()
    local map = LocalPlayer.state['tk_vip']
    return type(map) == 'table' and map or {}
end

exports('getVip', function()
    local map = getVipMap()
    return next(map) ~= nil
end)

exports('getVipJenis', function(jenis)
    if not jenis then return false end
    local map = getVipMap()
    return map[tonumber(jenis)] ~= nil
end)

-- ===== Admin Panel =====
-- Command untuk buka panel
RegisterCommand('vipadmin', function()
    local isAdmin = lib.callback.await('tk:vip:sv:isAdmin', false)
    if not isAdmin then
        lib.notify({ type='error', description='Kamu bukan admin VIP.' })
        return
    end
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        jenis  = Config.VipSystem.VipJenis,
        maxDays= Config.VipSystem.MaxDays or 365,
        lockTo = Config.VipSystem.LockCodeToIdentifier
    })
end)

-- Close Panel
RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'forceClose' })
    cb(true)
end)

-- Create Code
RegisterNUICallback('create_code', function(data, cb)
    -- pastikan data minimal table
    data = type(data) == 'table' and data or {}
    local resp = lib.callback.await('tk:vip:sv:create_code', false, data)
    cb(resp or { ok=false, error='Tidak ada respon' })
end)

-- List VIP
RegisterNUICallback('list_vip', function(data, cb)
    data = type(data) == 'table' and data or {}
    local resp = lib.callback.await('tk:vip:sv:list', false, data)
    cb(resp or { ok=false, error='Tidak ada respon' })
end)

-- Revoke VIP
RegisterNUICallback('revoke_vip', function(data, cb)
    data = type(data) == 'table' and data or {}
    TriggerServerEvent('tk:vip:sv:revoke', data)
    cb({ ok=true })
end)

-- Chat suggestions
CreateThread(function()
    TriggerEvent('chat:addSuggestion', '/vipinfo', 'Lihat VIP aktif milikmu', {})
    TriggerEvent('chat:addSuggestion', '/vipadmin', 'Buka panel Admin VIP', {})
    TriggerEvent('chat:addSuggestion', '/aktifvip', 'Aktifkan VIP dengan kode redeem', {
        { name = 'kode', help = 'Kode VIP (case-insensitive)' },
    })
end)

-- penggunaan
-- -- server
-- if exports.tk_vip:getVip(source) then ... end
-- if exports.tk_vip:getVipJenis(source, 2) then ... end

-- -- client
-- if exports.tk_vip:getVip() then ... end
-- if exports.tk_vip:getVipJenis(2) then ... end