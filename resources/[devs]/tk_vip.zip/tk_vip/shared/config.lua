local Config = {}

Config.VipSystem = {
    VipJenis = {
        [1] = 'Bronze',
        [2] = 'Silver',
        [3] = 'Gold',
    },

    CodeLength = 10,
    CodeCharset = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789',
    LockCodeToIdentifier = false,

    MaxDays = 365,
    DurationHint = 'Masukkan jumlah hari (integer). Contoh: 7 atau 30',

    SQL = {
        vipTable   = 'tk_vip',
        codesTable = 'tk_vip_codes',
        players    = 'players',  -- tabel default QBCore
    },

    PageSize = 20, -- NUI list pagination
}

if IsDuplicityVersion() then
    Config.VipSystem.AdminSteam = {
         'steam:11000013f5fbf6a',
    }
    Config.VipSystem.DiscordWebhook = 'https://discord.com/api/webhooks/1345955044276830239/7cakaXqTZAv1ZSO37S28ieEKgDePbQ0ceiyqQKOujxEFIHjd1Pv_MY88ciTCOYyTDf7m'
    Config.VipSystem.DiscordColor   = 0x8A2BE2

    -- Notifikasi kadaluarsa segera (hari)
    Config.VipSystem.ExpiryWarnDays = 3
end

return Config
