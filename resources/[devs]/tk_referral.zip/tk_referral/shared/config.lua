Config = {}

-- ==== CORE REQUIREMENT ==== 
-- TEST: 60 detik; PROD: 3600 (60 menit)
Config.RequirementSeconds = 60

-- Grace ganti kode
Config.Grace = { Enable = true, Minutes = 15, MaxActiveSeconds = 300 }

-- Kode
Config.Code = { Prefix = 'TIKUM-', RandomLength = 6 }

-- AFK & heartbeat (TEST nyaman)
Config.AfkDetect = {
  Enable = true,
  MaxIdleSeconds = 45,
  MinMoveDistance = 1.0,
  MinSpeed = 0.40,
  HeartbeatSecs = 2,
  TallyTickSecs = 5
}

-- Low DB writes
Config.Persistence = {
  ReferralFlushSecs = 30,
  WindowFlushSecs   = 60
}

-- Leaderboard
Config.Leaderboard = {
  TopN = 10,
  InGameRefreshMinutes = 60,
  DiscordRefreshHours  = 12,
  FallbackToLifetimeIfEmpty = true
}

-- HIDE/DECAY gating untuk papan (TEST per jam, 1 menit)
Config.DailyReferrerActivity = {
  Enable = true,
  Window = 'hour',     -- 'hour' (TEST) | 'day' (PROD)
  Minutes = 1,         -- TEST 1; PROD 60
  Policy = 'DECAY',    -- 'HIDE' | 'DECAY'
  DecayPerWindow = 1,  -- dipakai saat 'hour'
  DecayPerDay = 1,     -- dipakai saat 'day'
  Floor = 1,           -- skor minimum agar tidak hilang
  TimezoneOffsetMinutes = 420
}

-- Validasi (Opsi A multi-redeem → jangan blokir license/steam/discord)
Config.Validation = {
  UniquePer = { license = false, steam = false, discord = false, ip = true },
  UniquenessMode = 'ANY',
  UniqueIPWindowDays = 7,
  MaxRedeemsPerIPPerDay = 2,
  MaxConcurrentActiveByReferrer = 10
}

-- Hadiah (on-redeem dibuat CLAIM TERKUNCI, baru terbuka saat complete)
Config.Rewards = {
  ReferredOnRedeem   = { money = 0, items = {} },                -- tetap bisa diisi; akan dibuat locked
  ReferredOnComplete = { money = 5000, items = { bread=3, water=3 } },

  ReferrerMilestones = {
    [1]  = { money = 10000 },
    [2]  = { items = { phone = 1 } },
    [5]  = { money = 25000, items = { repairkit = 5 } },
    [10] = { money = 50000, items = { radio = 1 } },
  },

  MoneyAccount = 'cash',
  LockOnRedeemUntilComplete = true
}

-- Webhook (opsional)
Config.Webhook = { Enable = false, Url = '' }

-- UI
Config.UI = { Theme = 'purple-black' }

-- Debug
Config.Debug = {
  Enable = true,
  AfkVerbose = false,
  ExcludeDebugFromLeaderboard = false,
  ExcludeDebugFromMilestones  = false,
  AllowSelfRedeem = true
}