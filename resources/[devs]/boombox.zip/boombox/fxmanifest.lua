fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'tk_boombox'
author 'TITIK KUMPUL'
description 'Boombox QBCore + ox_lib + ox_target + xsound dengan carry, keybind, local volume, persist DB, saved songs, dan YouTube search'
version '2.0.0'

shared_scripts {
  '@ox_lib/init.lua',
  'config.lua'
}

client_scripts {
  'client.lua'
}

server_scripts {
  '@oxmysql/lib/MySQL.lua',
  'server.lua'
}
