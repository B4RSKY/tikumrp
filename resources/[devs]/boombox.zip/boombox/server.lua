local QBCore = exports['qb-core']:GetCoreObject()

-- State server: netId -> box
-- box = { dbId, owner, ownerCid, coords(vec3), playing, link, volume, distance, carried, carrier }
local ActiveBoxes = {}

-- Pending restore yang dibaca dari DB saat resource start
local PendingRestore = {}
local PendingWipes = {}  -- [cid] = token integer

-- ===================== UTIL =====================
local function isNear(a, b, r) return #(a - b) <= r end

local function getCoords(src)
  local ped = GetPlayerPed(src)
  if ped ~= 0 then return GetEntityCoords(ped) end
end

local function broadcast(ev, ...)
  TriggerClientEvent(ev, -1, ...)
end

local function clamp(v, lo, hi)
  if v < lo then return lo elseif v > hi then return hi else return v end
end

-- ===================== DB HELPERS =====================
local T_BOX = Config.DB.TableBoxes
local T_SONG = Config.DB.TableSongs

local function dbCreateBox(ownerCid, coords, link, volume, distance, playing)
  local sql = ("INSERT INTO `%s` (owner_cid, x, y, z, link, volume, distance, playing) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"):format(T_BOX)
  local id = MySQL.insert.await(sql, {
    ownerCid,
    coords.x, coords.y, coords.z,
    link or nil,                -- NULL di DB
    volume or Config.DefaultVolume,
    distance or Config.DefaultDistance,
    playing and 1 or 0
  })
  return id
end

local function dbListBoxesByCid(cid)
  local rows = MySQL.query.await(([[SELECT id, owner_cid, x, y, z, link, volume, distance, playing
                                    FROM `%s` WHERE owner_cid = ?]]):format(T_BOX), { cid }) or {}
  local out = {}
  for _, r in ipairs(rows) do
    out[#out+1] = {
      id        = r.id,
      ownerCid  = r.owner_cid,
      coords    = { x = r.x, y = r.y, z = r.z },   -- <<< bentuk coords
      link      = r.link,
      volume    = r.volume or Config.DefaultVolume,
      distance  = r.distance or Config.DefaultDistance,
      playing   = r.playing == 1
    }
  end
  return out
end

local function dbUpdateBox(id, fields)
  if not id or not fields then return end
  local sets, params = {}, {}
  for k, v in pairs(fields) do
    sets[#sets+1] = string.format("%s = ?", k)
    params[#params+1] = v
  end
  params[#params+1] = id
  local q = ("UPDATE `%s` SET %s WHERE id = ?"):format(T_BOX, table.concat(sets, ", "))
  MySQL.update(q, params)
end

local function dbDeleteBox(id)
  if not id then return end
  MySQL.update(("DELETE FROM `%s` WHERE id = ?"):format(T_BOX), { id })
end

local function dbLoadBoxes()
  local rows = MySQL.query.await(("SELECT id, owner_cid, x, y, z, link, volume, distance, playing FROM `%s`"):format(T_BOX)) or {}
  local out = {}
  for _, r in ipairs(rows) do
    out[#out+1] = {
      id = r.id,
      ownerCid = r.owner_cid,
      coords = { x = r.x, y = r.y, z = r.z },
      link = r.link,
      volume = r.volume or Config.DefaultVolume,
      distance = r.distance or Config.DefaultDistance,
      playing = r.playing == 1
    }
  end
  return out
end

local function scheduleWipeForCid(cid)
  if not cid then return end
  local token = (PendingWipes[cid] or 0) + 1
  PendingWipes[cid] = token
  SetTimeout(30 * 60 * 1000, function()
    -- Jika token masih sama, artinya player belum balik → hapus semua box milik cid ini
    if PendingWipes[cid] ~= token then return end
    MySQL.update(([[DELETE FROM `%s` WHERE owner_cid = ?]]):format(T_BOX), { cid })
    PendingWipes[cid] = nil
  end)
end

-- SONGS
local function dbInsertSong(cid, name, url)
  return MySQL.insert.await(([[INSERT INTO `%s` (owner_cid, name, url) VALUES (?, ?, ?)]]):format(T_SONG), { cid, name, url })
end

local function dbDeleteSong(cid, id)
  return MySQL.update(([[DELETE FROM `%s` WHERE id = ? AND owner_cid = ?]]):format(T_SONG), { id, cid })
end

local function dbListSongs(cid)
  return MySQL.query.await(([[SELECT id, name, url, created_at FROM `%s` WHERE owner_cid = ? ORDER BY id DESC LIMIT 100]]):format(T_SONG), { cid }) or {}
end

-- ===================== GUARD KONTROL =====================
local function canControl(src, netId)
  local box = ActiveBoxes[netId]
  if not box then return false, 'Box not found' end

  -- Owner check (via citizenid agar survive relog)
  if not Config.AllowPublicControl then
    if box.owner ~= src then
      local Player = QBCore.Functions.GetPlayer(src)
      local cid = Player and Player.PlayerData.citizenid
      if cid and box.ownerCid and cid == box.ownerCid then
        box.owner = src -- re-bind ke source saat ini
      else
        return false, 'Only owner can control'
      end
    end
  end

  -- Jika sedang dibawa owner, lewati cek jarak
  if box.carried and box.owner == src then
    return true
  end

  local p = getCoords(src); if not p then return false, 'Invalid player' end

  -- Pakai posisi entity bila ada; fallback ke box.coords
  local ref = box.coords
  local ent = NetworkGetEntityFromNetworkId(netId)
  if ent and DoesEntityExist(ent) then
    local epos = GetEntityCoords(ent)
    if epos then ref = epos end
  end

  if not ref or not isNear(p, ref, Config.ControlRadius + 2.0) then
    return false, 'Too far from boombox'
  end
  return true
end

-- ===================== USE ITEM =====================
QBCore.Functions.CreateUseableItem(Config.ItemName, function(source)
  TriggerClientEvent('tk_bb:cl:useBoombox', source)
end)

-- ===================== REGISTER BOX =====================
RegisterNetEvent('tk_bb:sv:registerBox', function(netId, coords)
  local src = source
  if not netId or not coords then return end
  local Player = QBCore.Functions.GetPlayer(src); if not Player then return end

  if Config.OneActivePerPlayer then
    for _, box in pairs(ActiveBoxes) do
      if box.owner == src then
        return TriggerClientEvent('ox_lib:notify', src, {type='error', title='Boombox', description='Kamu sudah punya boombox aktif'})
      end
    end
  end

  if not Player.Functions.GetItemByName(Config.ItemName) then
    return TriggerClientEvent('ox_lib:notify', src, {type='error', title='Boombox', description='Item tidak ditemukan'})
  end
  Player.Functions.RemoveItem(Config.ItemName, 1)

  local cid = Player.PlayerData.citizenid
  -- Buat row DB terlebih dulu
  local dbId = dbCreateBox(cid, coords, nil, Config.DefaultVolume, Config.DefaultDistance, false)

  ActiveBoxes[netId] = {
    dbId    = dbId,
    owner   = src,
    ownerCid= cid,
    coords  = vec3(coords.x, coords.y, coords.z),
    playing = false,
    link    = nil,
    volume  = Config.DefaultVolume,
    distance= Config.DefaultDistance,
    carried = false,
    carrier = nil,
  }

  TriggerClientEvent('ox_lib:notify', src, {type='success', title='Boombox', description='Boombox diletakkan'})
end)

-- Register hasil restore (client spawn ulang) — tidak konsumsi/beri item
RegisterNetEvent('tk_bb:sv:registerBoxRestored', function(netId, payload)
  if not netId or not payload or not payload.coords or not payload.dbId then return end
  ActiveBoxes[netId] = {
    dbId    = payload.dbId,
    owner   = 0, -- akan di-bind saat owner online & kontrol
    ownerCid= payload.ownerCid,
    coords  = vec3(payload.coords.x, payload.coords.y, payload.coords.z),
    playing = payload.playing and (payload.link ~= nil) or false,
    link    = payload.link,
    volume  = payload.volume or Config.DefaultVolume,
    distance= payload.distance or Config.DefaultDistance,
    carried = false,
    carrier = nil,
  }
  if ActiveBoxes[netId].playing then
    TriggerClientEvent('tk_bb:cl:applySound', -1, 'play', netId, {
      coords = payload.coords,
      link = ActiveBoxes[netId].link,
      volume = ActiveBoxes[netId].volume,
      distance = ActiveBoxes[netId].distance
    })
  end
end)

-- ===================== AUDIO =====================
RegisterNetEvent('tk_bb:sv:play', function(netId, link, volume, distance)
  local src = source
  local ok, msg = canControl(src, netId); if not ok then return TriggerClientEvent('ox_lib:notify', src, {type='error', title='Boombox', description=msg}) end
  local box = ActiveBoxes[netId]; if not box then return end

  volume   = clamp(tonumber(volume) or Config.DefaultVolume, 0.0, Config.MaxVolume)
  distance = math.floor(clamp(tonumber(distance) or Config.DefaultDistance, 1.0, Config.MaxDistance))

  if Config.AllowedDomains and #Config.AllowedDomains > 0 then
    local okDomain = false
    local l = string.lower(link or '')
    for _, d in ipairs(Config.AllowedDomains) do
      if string.find(l, string.lower(d), 1, true) then okDomain = true break end
    end
    if not okDomain then
      return TriggerClientEvent('ox_lib:notify', src, {type='error', title='Boombox', description='Link tidak diizinkan'})
    end
  end

  box.link, box.volume, box.distance, box.playing = link, volume, distance, true
  TriggerClientEvent('tk_bb:cl:applySound', -1, 'play', netId, {
    coords = { x = box.coords.x, y = box.coords.y, z = box.coords.z },
    link = link, volume = volume, distance = distance
  })

  -- DB update
  dbUpdateBox(box.dbId, {
    link = link, volume = volume, distance = distance, playing = 1
  })
end)

RegisterNetEvent('tk_bb:sv:stop', function(netId)
  local src = source
  local ok, msg = canControl(src, netId); if not ok then return TriggerClientEvent('ox_lib:notify', src, {type='error', title='Boombox', description=msg}) end
  local box = ActiveBoxes[netId]; if not box then return end
  box.playing = false
  TriggerClientEvent('tk_bb:cl:applySound', -1, 'stop', netId, {})
  dbUpdateBox(box.dbId, { playing = 0 })
end)

RegisterNetEvent('tk_bb:sv:volume', function(netId, volume)
  local src = source
  local ok, msg = canControl(src, netId); if not ok then return TriggerClientEvent('ox_lib:notify', src, {type='error', title='Boombox', description=msg}) end
  local box = ActiveBoxes[netId]; if not box then return end
  volume = clamp(tonumber(volume) or box.volume, 0.0, Config.MaxVolume)
  box.volume = volume
  TriggerClientEvent('tk_bb:cl:applySound', -1, 'volume', netId, { volume = volume })
  dbUpdateBox(box.dbId, { volume = volume })
end)

RegisterNetEvent('tk_bb:sv:distance', function(netId, distance)
  local src = source
  local ok, msg = canControl(src, netId); if not ok then return TriggerClientEvent('ox_lib:notify', src, {type='error', title='Boombox', description=msg}) end
  local box = ActiveBoxes[netId]; if not box then return end
  distance = math.floor(clamp(tonumber(distance) or box.distance, 1.0, Config.MaxDistance))
  box.distance = distance
  TriggerClientEvent('tk_bb:cl:applySound', -1, 'distance', netId, { distance = distance })
  dbUpdateBox(box.dbId, { distance = distance })
end)

-- ===================== CARRY / PLACE =====================
RegisterNetEvent('tk_bb:sv:setCarried', function(netId, state)
  if not Config.Carry.Enabled then return end
  local src = source
  local ok, msg = canControl(src, netId)
  if not ok then
    return TriggerClientEvent('ox_lib:notify', src, {type='error', title='Boombox', description=msg})
  end
  local box = ActiveBoxes[netId]; if not box then return end

  state = not not state
  if state then
    box.carried = true
    box.carrier = src
    TriggerClientEvent('tk_bb:cl:startCarry', src, netId)
    broadcast('tk_bb:cl:setCarried', netId, true, box.owner)
  else
    if box.carrier then TriggerClientEvent('tk_bb:cl:stopCarry', box.carrier, netId) end
    box.carried = false
    box.carrier = nil
    broadcast('tk_bb:cl:setCarried', netId, false, box.owner)
    -- coords akan diperbarui oleh tk_bb:sv:updateCoords
  end
end)

RegisterNetEvent('tk_bb:sv:updateCoords', function(netId, coords)
  local src = source
  local box = ActiveBoxes[netId]; if not box then return end
  if box.owner ~= src then
    local Player = QBCore.Functions.GetPlayer(src)
    local cid = Player and Player.PlayerData.citizenid
    if cid and box.ownerCid and cid == box.ownerCid then
      box.owner = src
    else
      return
    end
  end
  if not coords then return end
  box.coords = vec3(coords.x, coords.y, coords.z)
  dbUpdateBox(box.dbId, { x = coords.x, y = coords.y, z = coords.z })
end)

-- ===================== PICKUP =====================
RegisterNetEvent('tk_bb:sv:pickup', function(netId)
  local src = source
  local box = ActiveBoxes[netId]; if not box then return end

  -- owner check via citizenid
  if box.owner ~= src then
    local Player = QBCore.Functions.GetPlayer(src)
    local cid = Player and Player.PlayerData.citizenid
    if not (cid and box.ownerCid and cid == box.ownerCid) then
      return TriggerClientEvent('ox_lib:notify', src, {type='error', title='Boombox', description='Hanya owner yang bisa mengambil'})
    end
    box.owner = src
  end

  -- stop & hapus entity
  TriggerClientEvent('tk_bb:cl:applySound', -1, 'stop', netId, {})
  local ent = NetworkGetEntityFromNetworkId(netId)
  if ent and DoesEntityExist(ent) then DeleteEntity(ent) end
  SetTimeout(300, function()
    local ent2 = NetworkGetEntityFromNetworkId(netId)
    if ent2 and DoesEntityExist(ent2) then
      TriggerClientEvent('tk_bb:cl:requestDelete', -1, netId)
    end
  end)

  dbDeleteBox(box.dbId)
  ActiveBoxes[netId] = nil

  local Player = QBCore.Functions.GetPlayer(src)
  if Player then Player.Functions.AddItem(Config.ItemName, 1) end
  TriggerClientEvent('ox_lib:notify', src, {type='success', title='Boombox', description='Boombox diambil'})
end)

-- ===================== SYNC & RESTORE =====================
RegisterNetEvent('tk_bb:sv:requestSync', function()
  TriggerClientEvent('tk_bb:cl:syncAll', source, ActiveBoxes)
end)

-- load boxes from DB on resource start
-- Wipe semua boombox runtime saat resource start (TIDAK restore)
CreateThread(function()
  MySQL.update(("DELETE FROM `%s`"):format(T_BOX))
  PendingRestore = {}
  print('[tk_boombox] Wipe boxes on start: cleared table '..T_BOX)
end)

AddEventHandler('QBCore:Server:PlayerLoaded', function(Player)
  if not Player or not Player.PlayerData then return end
  local src = Player.PlayerData.source
  local cid = Player.PlayerData.citizenid
  if not cid then return end

  -- Batalkan semua wipe terjadwal untuk cid ini
  PendingWipes[cid] = (PendingWipes[cid] or 0) + 1

  -- Muat box milik cid dari DB (kalau masih ada → artinya belum lewat 30 menit)
  local saved = dbListBoxesByCid(cid)
  if saved and #saved > 0 then
    -- kirim hanya ke player ini untuk spawn ulang (client sudah punya handler restoreSpawn)
    TriggerClientEvent('tk_bb:cl:restoreSpawn', src, saved)
  end
end)

-- ===================== CLEANUP =====================
AddEventHandler('playerDropped', function()
  local src = source
  local Player = QBCore.Functions.GetPlayer(src)
  local cid = Player and Player.PlayerData.citizenid

  -- fallback kalau Player sudah nil: ambil cid dari salah satu box yang dimiliki source ini
  if not cid then
    for _, box in pairs(ActiveBoxes) do
      if box.owner == src and box.ownerCid then
        cid = box.ownerCid
        break
      end
    end
  end

  local remove = {}
  for netId, box in pairs(ActiveBoxes) do
    if box.owner == src or (cid and box.ownerCid == cid) then
      -- stop audio & delete entity di dunia
      TriggerClientEvent('tk_bb:cl:applySound', -1, 'stop', netId, {})
      local ent = NetworkGetEntityFromNetworkId(netId)
      if ent and DoesEntityExist(ent) then DeleteEntity(ent) end
      -- keluarkan dari state server (DB tetap disimpan, untuk kemungkinan restore)
      remove[#remove+1] = netId
    end
  end
  for _, id in ipairs(remove) do ActiveBoxes[id] = nil end

  -- jadwalkan wipe 30 menit untuk citizenid ini
  if cid then scheduleWipeForCid(cid) end
end)

AddEventHandler('onResourceStop', function(res)
  if res ~= GetCurrentResourceName() then return end
  for netId, _ in pairs(ActiveBoxes) do
    TriggerClientEvent('tk_bb:cl:applySound', -1, 'stop', netId, {})
    local ent = NetworkGetEntityFromNetworkId(netId)
    if ent and DoesEntityExist(ent) then DeleteEntity(ent) end
  end
  MySQL.update(("DELETE FROM `%s`"):format(T_BOX))
end)

-- ===================== SAVED SONGS (DB) =====================
-- Save song
RegisterNetEvent('tk_bb:sv:songSave', function(name, url)
  local src = source
  local Player = QBCore.Functions.GetPlayer(src)
  if not Player or not name or name == '' or not url or url == '' then
    return TriggerClientEvent('ox_lib:notify', src, {type='error', title='Boombox', description='Data lagu tidak valid'})
  end
  local cid = Player.PlayerData.citizenid
  dbInsertSong(cid, name, url)
  TriggerClientEvent('ox_lib:notify', src, {type='success', title='Boombox', description='Lagu disimpan'})
end)

-- Delete song
RegisterNetEvent('tk_bb:sv:songDelete', function(id)
  local src = source
  local Player = QBCore.Functions.GetPlayer(src)
  if not Player or not id then return end
  local cid = Player.PlayerData.citizenid
  dbDeleteSong(cid, id)
  TriggerClientEvent('ox_lib:notify', src, {type='success', title='Boombox', description='Lagu dihapus'})
end)

-- ox_lib callbacks
lib.callback.register('tk_bb:cb:getSongs', function(source)
  local Player = QBCore.Functions.GetPlayer(source)
  local cid = Player and Player.PlayerData.citizenid
  if not cid then return {} end
  return dbListSongs(cid)
end)

lib.callback.register('tk_bb:cb:searchYoutube', function(source, query)
  if not Config.YouTube or not Config.YouTube.APIKey or Config.YouTube.APIKey == 'PUT_YOUR_YOUTUBE_API_KEY_HERE' then
    return { error = 'YouTube API key belum diisi di shared/config.lua' }
  end
  if not query or query == '' then return {} end

  local encodedQuery = query:gsub(" ", "%%20")
  local url = string.format(
    "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=%d&q=%s&key=%s",
    Config.YouTube.MaxResults or 5, encodedQuery, Config.YouTube.APIKey
  )

  local p = promise.new()
  PerformHttpRequest(url, function(statusCode, response)
    if statusCode == 200 then
      local data = json.decode(response) or {}
      local items = {}
      if data.items then
        for _, it in ipairs(data.items) do
          local vid = it.id and it.id.videoId
          local title = it.snippet and it.snippet.title or 'Unknown'
          local u = vid and ('https://www.youtube.com/watch?v='..vid) or nil
          if u then
            items[#items+1] = {
              id = vid,
              title = title,
              channel = it.snippet and it.snippet.channelTitle or '',
              url = u,
              publishedAt = it.snippet and it.snippet.publishedAt or '',
              thumb = ('https://img.youtube.com/vi/%s/hqdefault.jpg'):format(vid)  -- 👈 thumbnail
            }
          end
        end
      end
      p:resolve(items)
    else
      print(('[tk_boombox] YouTube API failed (%s): %s'):format(statusCode, tostring(response)))
      p:resolve({})
    end
  end, "GET", "", { ["Content-Type"] = "application/json" })

  return Citizen.Await(p)
end)