Config = {}

-- ITEM NAME di QBCore
Config.ItemName = 'boombox'

-- Prop model
Config.Model = `prop_boombox_01`

-- Default audio
Config.DefaultDistance = 25
Config.MaxDistance     = 80
Config.DefaultVolume   = 0.5 -- 0.0 - 1.0
Config.MaxVolume       = 1.0

-- Kontrol
Config.AllowPublicControl = false
Config.OneActivePerPlayer = true
Config.ControlRadius      = 6.0

-- Whitelist domain (opsional; kosongkan {} untuk menonaktifkan)
Config.AllowedDomains = { 'youtube.com', 'youtu.be', 'soundcloud.com' }

-- UI lokal
Config.UI = Config.UI or {}
Config.UI.ShowLocalVolume = true   -- tampilkan menu "My Volume (you only)"

-- Keybinds (bisa diubah user di Settings > Keybinds > FiveM)
Config.Keybinds = {
  Place = 'G',     -- letakkan di tanah saat sedang dibawa
  Store = 'K',     -- simpan jadi item saat sedang dibawa
}

-- Pegang / Carry
Config.Carry = {
  Enabled = true,
  Bone = 57005,                 -- Right hand
  Offset = vec3(0.32, 0.00, -0.05),
  Rot    = vec3(0.10, 270.0, 60.0),
  AnimDict = 'anim@heists@box_carry@',
  AnimName = 'idle',
  KeepPlaying = true,
  DisableSprint = true,
  DisableJump = true
}

-- Interval update posisi suara ketika sedang dibawa (ms)
Config.CarryPositionUpdateMs = 350

-- =================== DATABASE ===================
Config.DB = {
  TableBoxes = 'tk_boombox_boxes',
  TableSongs = 'tk_boombox_songs',
}

-- ================== YOUTUBE SEARCH ==================
Config.YouTube = {
  APIKey = 'AIzaSyAh3_JAiC3NqgywqHZ2r9TAVYqQvzWc49Q', -- <==== ISI DENGAN API KEY-MU
  MaxResults = 5
}
    