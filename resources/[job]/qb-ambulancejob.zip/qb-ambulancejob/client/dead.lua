local deadAnimDict = 'dead'
local deadAnim = 'dead_a'
local hold = 5
deathTime = 0

-- Functions

local function loadAnimDict(dict)
    while (not HasAnimDictLoaded(dict)) do
        RequestAnimDict(dict)
        Wait(5)
    end
end

function OnDeath()
    if not isDead then
        isDead = true
        TriggerServerEvent('hospital:server:SetDeathStatus', true)
        TriggerServerEvent('InteractSound_SV:PlayOnSource', 'demo', 0.1)
        local player = PlayerPedId()

        while GetEntitySpeed(player) > 0.5 or IsPedRagdoll(player) do
            Wait(10)
        end

        if isDead then
            local pos = GetEntityCoords(player)
            local heading = GetEntityHeading(player)

            local ped = PlayerPedId()
            if IsPedInAnyVehicle(ped) then
                local veh = GetVehiclePedIsIn(ped)
                local vehseats = GetVehicleModelNumberOfSeats(GetHashKey(GetEntityModel(veh)))
                for i = -1, vehseats do
                    local occupant = GetPedInVehicleSeat(veh, i)
                    if occupant == ped then
                        NetworkResurrectLocalPlayer(pos.x, pos.y, pos.z + 0.5, heading, true, false)
                        SetPedIntoVehicle(ped, veh, i)
                    end
                end
            else
                NetworkResurrectLocalPlayer(pos.x, pos.y, pos.z + 0.5, heading, true, false)
            end

            SetEntityInvincible(player, true)
            SetEntityHealth(player, GetEntityMaxHealth(player))
            if IsPedInAnyVehicle(player, false) then
                loadAnimDict('veh@low@front_ps@idle_duck')
                TaskPlayAnim(player, 'veh@low@front_ps@idle_duck', 'sit', 1.0, 1.0, -1, 1, 0, 0, 0, 0)
            else
                loadAnimDict(deadAnimDict)
                TaskPlayAnim(player, deadAnimDict, deadAnim, 1.0, 1.0, -1, 1, 0, 0, 0, 0)
            end
			if Config.Dispatch == "ps-dispatch" then
				exports['ps-dispatch']:DeceasedPerson()
			else
				TriggerServerEvent('hospital:server:ambulanceAlert', Lang:t('info.civ_died'))
			end
        end
    end
end

function DeathTimer()
    hold = 5
    while isDead do
        Wait(1000)
        deathTime = deathTime - 1
        if deathTime <= 0 then
            if IsControlPressed(0, 38) and hold <= 0 and not isInHospitalBed then
                TriggerEvent('hospital:client:RespawnAtHospital')
                hold = 5
            end
            if IsControlPressed(0, 38) then
                if hold - 1 >= 0 then
                    hold = hold - 1
                else
                    hold = 0
                end
            end
            if IsControlReleased(0, 38) then
                hold = 5
            end
        end
    end
end

local function DrawTxt(x, y, width, height, scale, text, r, g, b, a, _)
    SetTextFont(4)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0, 255)
    SetTextEdge(2, 0, 0, 0, 255)
    SetTextDropShadow()
    SetTextOutline()
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(x - width / 2, y - height / 2 + 0.005)
end

-- Damage Handler
local BulletAmmoTypes = {
  AMMO_PISTOL   = true,
  AMMO_SMG      = true,
  AMMO_RIFLE    = true,
  AMMO_MG       = true,
  AMMO_SHOTGUN  = true,
  AMMO_SNIPER   = true,
  AMMO_MUSKET   = true,
  AMMO_MINISMG  = true,
}

local function IsGunshot(weaponHash)
    if not weaponHash or weaponHash == 0 then
        return false
    end

    local w = QBCore and QBCore.Shared and QBCore.Shared.Weapons and QBCore.Shared.Weapons[weaponHash]
    if not w then
        return false
    end

    local ammoType = w.ammotype or w.ammo
    if not ammoType then
        return false
    end

    return BulletAmmoTypes[ammoType] == true
end

AddEventHandler('gameEventTriggered', function(event, data)
    if event ~= 'CEventNetworkEntityDamage' then return end

    local victim      = data[1]
    local attacker    = data[2]
    local victimDied  = data[4]
    local weapon      = data[7]

    if not IsEntityAPed(victim) then return end

    if not victimDied then return end
    if NetworkGetPlayerIndexFromPed(victim) ~= PlayerId() then return end
    if not IsEntityDead(PlayerPedId()) then return end

    local ketembak = IsGunshot(weapon)

    if ketembak then
        if InLaststand then
            SetLaststand(false)
        end

        local playerid   = NetworkGetPlayerIndexFromPed(victim)
        local playerName = (GetPlayerName(playerid) .. ' (' .. GetPlayerServerId(playerid) .. ')') or Lang:t('info.self_death')

        local killerId   = NetworkGetPlayerIndexFromPed(attacker)
        local killerName = (GetPlayerName(killerId) .. ' (' .. GetPlayerServerId(killerId) .. ')') or Lang:t('info.self_death')

        local weaponLabel = (QBCore.Shared.Weapons and QBCore.Shared.Weapons[weapon] and QBCore.Shared.Weapons[weapon].label) or 'Unknown'
        local weaponName  = (QBCore.Shared.Weapons and QBCore.Shared.Weapons[weapon] and QBCore.Shared.Weapons[weapon].name) or 'Unknown'

        TriggerServerEvent('qb-log:server:CreateLog', 'death', Lang:t('logs.death_log_title', { playername = playerName, playerid = GetPlayerServerId(playerid) }), 'red', Lang:t('logs.death_log_message', { killername = killerName, playername = playerName, weaponlabel = weaponLabel, weaponname = weaponName })
        )

        deathTime = Config.DeathTime
        OnDeath()
        DeathTimer()

    else
        if not InLaststand then
            SetLaststand(true)
        elseif InLaststand and not isDead then
            SetLaststand(false)

            local playerid   = NetworkGetPlayerIndexFromPed(victim)
            local playerName = (GetPlayerName(playerid) .. ' (' .. GetPlayerServerId(playerid) .. ')') or Lang:t('info.self_death')

            local killerId   = NetworkGetPlayerIndexFromPed(attacker)
            local killerName = (GetPlayerName(killerId) .. ' (' .. GetPlayerServerId(killerId) .. ')') or Lang:t('info.self_death')

            local weaponLabel = (QBCore.Shared.Weapons and QBCore.Shared.Weapons[weapon] and QBCore.Shared.Weapons[weapon].label) or 'Unknown'
            local weaponName  = (QBCore.Shared.Weapons and QBCore.Shared.Weapons[weapon] and QBCore.Shared.Weapons[weapon].name) or 'Unknown'

            TriggerServerEvent('qb-log:server:CreateLog', 'death', Lang:t('logs.death_log_title', { playername = playerName, playerid = GetPlayerServerId(playerid) }), 'red', Lang:t('logs.death_log_message', { killername = killerName, playername = playerName, weaponlabel = weaponLabel, weaponname = weaponName }))

            deathTime = Config.DeathTime
            OnDeath()
            DeathTimer()
        end
    end
end)

-- Threads

emsNotified = false

CreateThread(function()
    while true do
        local sleep = 1000
        if isDead or InLaststand then
            sleep = 5
            local ped = PlayerPedId()
            if IsPauseMenuActive() then
                SetFrontendActive(false)
            end
            DisableAllControlActions(0)
            EnableControlAction(0, 1, true)
            EnableControlAction(0, 2, true)
            EnableControlAction(0, 245, true)
            EnableControlAction(0, 38, true)
            EnableControlAction(0, 0, true)
            EnableControlAction(0, 322, true)
            EnableControlAction(0, 288, true)
            EnableControlAction(0, 213, true)
            EnableControlAction(0, 249, true)
            EnableControlAction(0, 46, true)
            EnableControlAction(0, 47, true)

            if isDead then
                if not isInHospitalBed then
                    if deathTime > 0 then
                        DrawTxt(0.88, 1.44, 1.0, 1.0, 0.6, 'GUNAKAN COMMAND ~r~/aimedis~s~ UNTUK AUTO REVIVE, JIKA TIDAK ADA EMS', 255, 255, 255, 255)
                        DrawTxt(0.93, 1.44, 1.0, 1.0, 0.6, Lang:t('info.respawn_txt', { deathtime = math.ceil(deathTime) }), 255, 255, 255, 255)
                    else
                        DrawTxt(0.93, 1.44, 1.0, 1.0, 0.6, 'GUNAKAN COMMAND ~r~/aimedis~s~ UNTUK AUTO REVIVE, JIKA TIDAK ADA EMS', 255, 255, 255, 255)
                        DrawTxt(0.865, 1.44, 1.0, 1.0, 0.6, Lang:t('info.respawn_revive', { holdtime = hold, cost = Config.BillCost }), 255, 255, 255, 255)
                    end
                end

                if IsPedInAnyVehicle(ped, false) then
                    loadAnimDict('veh@low@front_ps@idle_duck')
                    if not IsEntityPlayingAnim(ped, 'veh@low@front_ps@idle_duck', 'sit', 3) then
                        TaskPlayAnim(ped, 'veh@low@front_ps@idle_duck', 'sit', 1.0, 1.0, -1, 1, 0, 0, 0, 0)
                    end
                else
                    if isInHospitalBed then
                        if not IsEntityPlayingAnim(ped, inBedDict, inBedAnim, 3) then
                            loadAnimDict(inBedDict)
                            TaskPlayAnim(ped, inBedDict, inBedAnim, 1.0, 1.0, -1, 1, 0, 0, 0, 0)
                        end
                    else
                        if not IsEntityPlayingAnim(ped, deadAnimDict, deadAnim, 3) then
                            loadAnimDict(deadAnimDict)
                            TaskPlayAnim(ped, deadAnimDict, deadAnim, 1.0, 1.0, -1, 1, 0, 0, 0, 0)
                        end
                    end
                end

                SetCurrentPedWeapon(ped, `WEAPON_UNARMED`, true)
            elseif InLaststand then
                sleep = 5

                if LaststandTime > Config.MinimumRevive then
                    DrawTxt(0.88, 1.44, 1.0, 1.0, 0.6, 'GUNAKAN COMMAND ~r~/aimedis~s~ UNTUK AUTO REVIVE, JIKA TIDAK ADA EMS', 255, 255, 255, 255)
                    DrawTxt(0.94, 1.40, 1.0, 1.0, 0.6, Lang:t('info.bleed_out', { time = math.ceil(LaststandTime) }), 255, 255, 255, 255)
                else
                    DrawTxt(0.88, 1.36, 1.0, 1.0, 0.6, 'GUNAKAN COMMAND ~r~/aimedis~s~ UNTUK AUTO REVIVE, JIKA TIDAK ADA EMS', 255, 255, 255, 255)
                    DrawTxt(0.845, 1.44, 1.0, 1.0, 0.6, Lang:t('info.bleed_out_help', { time = math.ceil(LaststandTime) }), 255, 255, 255, 255)
                    if not emsNotified then
                        DrawTxt(0.91, 1.40, 1.0, 1.0, 0.6, Lang:t('info.request_help'), 255, 255, 255, 255)
                    else
                        DrawTxt(0.90, 1.40, 1.0, 1.0, 0.6, Lang:t('info.help_requested'), 255, 255, 255, 255)
                    end

                    if IsControlJustPressed(0, 47) and not emsNotified then
						if Config.Dispatch == "ps-dispatch" then
							exports['ps-dispatch']:DeceasedPerson()
						else
							TriggerServerEvent('hospital:server:ambulanceAlert', Lang:t('info.civ_down'))
						end
                        emsNotified = true
                    end
                end
            end
        end
        Wait(sleep)
    end
end)
