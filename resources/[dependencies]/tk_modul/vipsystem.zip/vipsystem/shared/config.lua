local Config = {}

Config.VipSystem = {
    -- Jenis VIP (integer → nama untuk display/log)
    VipJenis = {
        [1] = 'Bronze',
        [2] = 'Silver',
        [3] = 'Gold',
    },

    -- Kode
    CodeLength = 10,
    CodeCharset = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789',
    LockCodeToIdentifier = false,   -- true: kode dikunci ke identifier target (license)

    -- Batas input admin (opsional, amankan nilai ekstrem)
    MaxDays = 365,                  -- batasi 1..365 hari (ubah sesuai kebutuhan)

    -- Hint UI
    DurationHint = 'Masukkan jumlah hari (integer). Contoh: 7 atau 30',

    -- Database tables
    SQL = {
        vipTable   = 'tk_vip',
        codesTable = 'tk_vip_codes',
    },
}

-- ====== SERVER-ONLY (tidak diload di client) ======
if IsDuplicityVersion() then
    Config.VipSystem.AdminSteam = {
        'steam:11000013f5fbf6a',
    }
    Config.VipSystem.DiscordWebhook = 'https://discord.com/api/webhooks/1345955044276830239/7cakaXqTZAv1ZSO37S28ieEKgDePbQ0ceiyqQKOujxEFIHjd1Pv_MY88ciTCOYyTDf7m'    -- isi webhook
    Config.VipSystem.DiscordColor   = 0x8A2BE2
end

return Config