local Config = require 'vipsystem.shared.config'
local Vs = Config.VipSystem

-- Sync statebag saat masuk
CreateThread(function()
    TriggerServerEvent('tk:vip:sv:refresh')
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    TriggerServerEvent('tk:vip:sv:refresh')
end)

-- Client exports via statebag
local function getVipMap()
    local map = LocalPlayer.state['tk_vip']
    return type(map) == 'table' and map or {}
end

exports('getVip', function()
    -- Ada entry apapun = VIP aktif (server hanya kirim yang belum expired)
    local map = getVipMap()
    return next(map) ~= nil
end)

exports('getVipJenis', function(jenis)
    if not jenis then return false end
    local map = getVipMap()
    return map[tonumber(jenis)] ~= nil
end)

RegisterCommand('rfereshvip', function (source, args, raw)
    TriggerServerEvent('tk:vip:sv:refresh')
end)

-- Chat suggestions
-- CreateThread(function()
--     TriggerEvent('chat:addSuggestion', '/buatvip', ('Buat kode VIP (Admin). %s'):format(Vs.DurationHint), {
--         { name = 'id',    help = 'Server ID target' },
--         { name = 'jenis', help = 'Integer jenis VIP (mis: 1=Bronze, 2=Silver, 3=Gold)' },
--         { name = 'hari',  help = 'Jumlah hari (integer), contoh: 7 atau 30' },
--     })
--     TriggerEvent('chat:addSuggestion', '/aktifvip', 'Aktifkan VIP dengan kode redeem', {
--         { name = 'kode', help = 'Kode VIP (case-insensitive)' },
--     })
-- end)
