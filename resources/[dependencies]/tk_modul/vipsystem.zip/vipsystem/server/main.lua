local Config = require 'vipsystem.shared.config'
local Vs = Config.VipSystem
local QBCore = exports['qb-core']:GetCoreObject()

-- =========================[ Utils ]=========================

local function getIdentifier(src, typ)
    if not src then return nil end
    for _, v in ipairs(GetPlayerIdentifiers(src)) do
        if v:find(typ..':', 1, true) == 1 then
            return v
        end
    end
    return nil
end

local function getSteamHex(src)
    return getIdentifier(src, 'steam')
end

local function getLicense(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if Player and Player.PlayerData and Player.PlayerData.license then
        return Player.PlayerData.license
    end
    return getIdentifier(src, 'steam')
end

local function isAuthedAdmin(src)
    local steam = getSteamHex(src)
    if not steam then return false end
    for _, hex in ipairs(Vs.AdminSteam or {}) do
        if hex == steam then return true end
    end
    return false
end

local function nowUtc() return os.time(os.date('!*t')) end
local function toDatetime(unix) return os.date('!%Y-%m-%d %H:%M:%S', unix) end

-- Durasi: integer hari → detik
local function parseDaysToSeconds(val)
    local n = tonumber(val)
    if not n or n <= 0 then return nil end
    if Vs.MaxDays and n > Vs.MaxDays then n = Vs.MaxDays end
    return n * 86400
end

local function genCode()
    local chars, len = Vs.CodeCharset, Vs.CodeLength
    local r = {}
    for i = 1, len do
        local idx = math.random(#chars)
        r[i] = chars:sub(idx, idx)
    end
    return table.concat(r)
end

local function sendDiscord(title, fields)
    if not Vs.DiscordWebhook or Vs.DiscordWebhook == '' then return end
    local embedFields = {}
    for k, v in pairs(fields or {}) do
        embedFields[#embedFields+1] = { name = tostring(k), value = tostring(v), inline = true }
    end
    local payload = json.encode({
        embeds = {{
            title = title,
            color = Vs.DiscordColor or 0x8A2BE2,
            fields = embedFields,
            timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ')
        }}
    })
    PerformHttpRequest(Vs.DiscordWebhook, function() end, 'POST', payload, {['Content-Type'] = 'application/json'})
end

local function fetchActiveVipMap(license)
    if not license then return {} end
    local rows = MySQL.query.await(([[SELECT jenis, UNIX_TIMESTAMP(expires_at) AS exp
                                      FROM %s
                                      WHERE identifier = ? AND expires_at > UTC_TIMESTAMP()]])
                                      :format(Vs.SQL.vipTable), { license })
    local map = {}
    for _, r in ipairs(rows or {}) do
        map[tonumber(r.jenis)] = tonumber(r.exp)
    end
    return map
end

local function setPlayerVipStatebag(src, vipMap)
    local p = Player(src)
    if p and p.state then
        p.state:set('tk_vip', vipMap or {}, true)
    end
end

local function refreshPlayerVip(src)
    local license = getLicense(src)
    if not license then setPlayerVipStatebag(src, {}) return end
    local vipMap = fetchActiveVipMap(license)
    setPlayerVipStatebag(src, vipMap)
end

-- =========================[ Commands ]=========================

-- /buatvip <id> <jenis:int> <durasi_hari:int>
RegisterCommand('buatvip', function(src, args)
    if src <= 0 then
        print('[tk_vip] Command ini hanya untuk in-game.')
        return
    end
    if not isAuthedAdmin(src) then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Tidak berhak. Hubungi owner.' })
        return
    end

    local targetId = tonumber(args[1] or '')
    local jenis    = tonumber(args[2] or '')
    local daysStr  = args[3]

    if not targetId or not jenis or not daysStr then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = ('Format: /buatvip <id> <jenis:int> <hari:int> | %s'):format(Vs.DurationHint) })
        return
    end
    if not GetPlayerName(targetId) then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Player target tidak online.' })
        return
    end
    if not Vs.VipJenis[jenis] then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Jenis VIP tidak dikenal.' })
        return
    end

    local durSec = parseDaysToSeconds(daysStr)
    if not durSec then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = ('Durasi tidak valid. %s'):format(Vs.DurationHint) })
        return
    end

    local creatorSteam = getSteamHex(src) or 'unknown'
    local creatorName  = GetPlayerName(src) or ('ID '..src)
    local targetName   = GetPlayerName(targetId) or ('ID '..targetId)
    local targetLic    = getLicense(targetId)

    -- Generate kode unik
    local code, ok
    for _=1,5 do
        code = genCode()
        local row = MySQL.single.await(([[SELECT code FROM %s WHERE code = ?]]):format(Vs.SQL.codesTable), { code })
        if not row then ok = true break end
    end
    if not ok then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Gagal membuat kode, coba lagi.' })
        return
    end

    local intendedIdentifier = Vs.LockCodeToIdentifier and targetLic or nil

    MySQL.insert.await(([[INSERT INTO %s
        (code, jenis, duration_seconds, created_by, created_by_name, created_at, intended_identifier)
        VALUES (?, ?, ?, ?, ?, NOW(), ?)]])
        :format(Vs.SQL.codesTable),
        { code, jenis, durSec, creatorSteam, creatorName, intendedIdentifier }
    )

    sendDiscord('VIP Code Created', {
        ['Code']  = code,
        ['Jenis'] = ('%d (%s)'):format(jenis, Vs.VipJenis[jenis]),
        ['Durasi'] = (tostring(math.floor(durSec/86400)) .. ' hari'),
        ['Target'] = ('%s (ID %d)'):format(targetName, targetId),
        ['Intended Lock'] = intendedIdentifier or '-',
        ['Creator'] = ('%s (%s)'):format(creatorName, creatorSteam),
    })

    TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = ('Kode VIP dibuat: %s (cek Discord log)'):format(code) })
end, false)

-- Cooldown sederhana anti brute-force
local redeemCooldown = {}

-- /aktifvip <kode>
RegisterCommand('aktifvip', function(src, args)
    if src <= 0 then return end
    local code = (args[1] or ''):upper()
    if code == '' then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Format: /aktifvip <kode>' })
        return
    end

    -- cooldown pendek anti brute force
    local nowU = os.time()
    _G._tkVipCd = _G._tkVipCd or {}
    if (nowU - (_G._tkVipCd[src] or 0)) < 3 then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Terlalu cepat, coba lagi...' })
        return
    end
    _G._tkVipCd[src] = nowU

    local row = MySQL.single.await(([[SELECT code, jenis, duration_seconds, used_by, intended_identifier
                                      FROM %s WHERE code = ?]]):format(Vs.SQL.codesTable), { code })
    if not row then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Kode tidak ditemukan.' })
        return
    end
    if row.used_by and row.used_by ~= '' then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Kode sudah digunakan.' })
        return
    end

    local license = getLicense(src)
    if Vs.LockCodeToIdentifier and row.intended_identifier and row.intended_identifier ~= license then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Kode ini tidak ditujukan untuk akunmu.' })
        return
    end

    local jenis     = tonumber(row.jenis)
    local durSec    = tonumber(row.duration_seconds)
    local playerName= GetPlayerName(src) or ('ID '..src)
    local steam     = getSteamHex(src) or 'unknown'

    -- >>>>>>> INI BAGIAN YANG KAMU TANYA – tempel di sini <<<<<<<
    -- Set/extend expiry langsung di MySQL (UTC), anti-mismatch timezone
    MySQL.prepare.await(([[INSERT INTO %s (identifier, jenis, expires_at)
VALUES (?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND))
ON DUPLICATE KEY UPDATE
  expires_at = DATE_ADD(GREATEST(expires_at, UTC_TIMESTAMP()), INTERVAL ? SECOND)]])
    :format(Vs.SQL.vipTable), { license, jenis, durSec, durSec })

    -- Ambil expiry terbaru untuk notifikasi/log (format YYYY-mm-dd HH:ii:ss)
    local newExpiry = MySQL.scalar.await(
        ([[SELECT DATE_FORMAT(expires_at, '%%Y-%%m-%%d %%H:%%i:%%s')
           FROM %s WHERE identifier = ? AND jenis = ?]])
        :format(Vs.SQL.vipTable), { license, jenis }
    )
    -- >>>>>>> SAMPAI SINI <<<<<<<

    -- Tandai kode terpakai (pakai UTC juga)
    MySQL.update.await(([[UPDATE %s
        SET used_by = ?, used_by_name = ?, used_at = UTC_TIMESTAMP()
        WHERE code = ?]]):format(Vs.SQL.codesTable), { license, playerName, code })

    -- Sync statebag ke client
    refreshPlayerVip(src)

    -- Notif & log
    TriggerClientEvent('ox_lib:notify', src, { type = 'success',
        description = ('VIP %s aktif sampai %s'):format(Vs.VipJenis[jenis] or jenis, newExpiry) })

    sendDiscord('VIP Redeemed', {
        ['Code']     = code,
        ['Jenis']    = ('%d (%s)'):format(jenis, Vs.VipJenis[jenis]),
        ['Redeemer'] = ('%s (%s)'):format(playerName, steam),
        ['License']  = license or '-',
        ['Expires']  = newExpiry,
    })
end, false)


-- =========================[ Hooks / Events ]=========================

AddEventHandler('QBCore:Server:PlayerLoaded', function(Player)
    local src = type(Player) == 'table' and Player.PlayerData and Player.PlayerData.source or Player
    if src then refreshPlayerVip(src) end
end)

RegisterNetEvent('tk:vip:sv:refresh', function()
    local src = source
    refreshPlayerVip(src)
end)

AddEventHandler('playerDropped', function()
    local src = source
    local p = Player(src)
    if p and p.state then
        p.state:set('tk_vip', {}, true)
    end
end)

-- =========================[ Server Exports ]=========================

-- ganti exports lama kamu

exports('getVip', function(srcId)
    if not srcId then return false end

    -- 1) Coba dari statebag (paling akurat & murah)
    local p = Player(srcId)
    if p and p.state then
        local map = p.state.tk_vip
        if type(map) == 'table' and next(map) ~= nil then
            return true
        end
    end

    -- 2) Fallback DB (kalau player belum keburu sync)
    local license = getLicense(srcId)
    if not license then return false end
    local row = MySQL.single.await(([[SELECT 1 FROM %s 
        WHERE identifier = ? AND expires_at > UTC_TIMESTAMP() LIMIT 1]])
        :format(Vs.SQL.vipTable), { license })
    return row ~= nil
end)

exports('getVipJenis', function(srcId, jenis)
    if not srcId or not jenis then return false end

    -- 1) Statebag dulu
    local p = Player(srcId)
    if p and p.state then
        local map = p.state.tk_vip
        if type(map) == 'table' and map[tonumber(jenis)] ~= nil then
            return true
        end
    end

    -- 2) Fallback DB
    local license = getLicense(srcId)
    if not license then return false end
    local row = MySQL.single.await(([[SELECT 1 FROM %s
        WHERE identifier = ? AND jenis = ? AND expires_at > UTC_TIMESTAMP() LIMIT 1]])
        :format(Vs.SQL.vipTable), { license, jenis })
    return row ~= nil
end)

RegisterCommand('vipdebug', function(src)
    if src <= 0 then print('Jalankan di in-game') return end
    local lic = getLicense(src)
    print(('[tk_vip] src=%s license=%s'):format(src, lic or 'nil'))

    local rows = MySQL.query.await(([[SELECT jenis, expires_at FROM %s WHERE identifier = ? ORDER BY expires_at DESC]])
      :format(Vs.SQL.vipTable), { lic })
    print('[tk_vip] rows:', json.encode(rows))

    local svHasAny = exports.tk_modul:getVip(src) -- ganti tk_modul dgn nama resource VIP kamu
    print('[tk_vip] server export getVip(src)=', svHasAny)

    local map = fetchActiveVipMap(lic)
    print('[tk_vip] active map (server view)=', json.encode(map))
end, false)
